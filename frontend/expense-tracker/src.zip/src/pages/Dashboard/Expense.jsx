import React from 'react'

const Expense = () => {
  return (
    <div>Expense</div>
  )
}

export default Expense