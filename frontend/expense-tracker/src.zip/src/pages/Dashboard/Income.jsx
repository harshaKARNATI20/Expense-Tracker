import React from 'react'

const income = () => {
  return (
    <div>income</div>
  )
}

export default income